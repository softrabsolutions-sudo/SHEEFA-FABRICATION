<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Meta Tags -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="author" content="themexriver">

    <!-- Page Title -->
    <title> About Us </title>

    <!-- Icon fonts -->
    <link href="assets/css/font-awesome.min.css" rel="stylesheet">
   <link rel="icon" type="image/x-icon" href="assets/images/sheefa-120x120.jpg">
    <!-- Bootstrap core CSS -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/7.0.1/css/all.min.css" />
    <!-- Plugins for this template -->
    <link href="assets/css/animate.css" rel="stylesheet">
    <link href="assets/css/owl.carousel.css" rel="stylesheet">
    <link href="assets/css/owl.theme.css" rel="stylesheet">
    <link href="assets/css/slick.css" rel="stylesheet">
    <link href="assets/css/slick-theme.css" rel="stylesheet">
    <link href="assets/css/owl.transitions.css" rel="stylesheet">
    <link href="assets/css/jquery.fancybox.css" rel="stylesheet">
    <link href="assets/css/magnific-popup.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="assets/css/style.css" rel="stylesheet">

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body>

    <!-- start page-wrapper -->
    <div class="page-wrapper">

        <!-- start preloader -->
        <div class="preloader">
            <div class="preloader-inner">
                <img src="assets/images/preloader.gif" alt>
            </div>
        </div>
        <!-- end preloader -->

        <!-- Start header -->
       <?php include('header.php');?>
        <!-- end of header -->


        <!-- start page-title -->
        <section class="page-title">
            <div class="container">
                <div class="row">
                    <div class="col col-xs-12">
                        <div class="title-breadcrumb">
                            <h2>About Company</h2>
                            <ol class="breadcrumb">
                                <li><a href="index.php">Home</a></li>
                                <li>Sheefa Fabrication Engineering Works</li>
                            </ol>
                        </div>
                    </div>
                </div> <!-- end row -->
            </div> <!-- end container -->
        </section>        
        <!-- end page-title -->


        <!-- start about-section-s3 -->
        <section class="about-section-s3 section-padding">
            <div class="container">
                <div class="row">
                    <div class="col col-md-6">
                        <div class="about-img">
                            <img src="assets/images/product-jpeg-500x500.jpg" alt>
                            <img src="assets/images/ui.jpg" alt="">
                        </div>
                    </div>
                    <div class="col col-md-6">
                        <div class="about-text">
                            <div class="title">
                                <span>About Us</span>
                                <h2>Sheefa Fabrication Engineering Works</h2>
                            </div>
                            <p style="text-align: justify;"> Prefabricated StructuresWe excel in the design, fabrication, and installation of cutting-edge prefabricated structures that offer rapid deployment, structural integrity, and long-term utility. Our specialized offerings include: Factory Shelters: Sturdy and reliable shelters providing essential protection and operational space within factory environments. Custom-Designed Sheds: Tailored solutions crafted to meet unique client specifications, ensuring both functional excellence and aesthetic appeal.2. Portable ContainersWe provide a versatile range of highly durable and adaptable portable containers, renowned for their convenience and mobility across various operational needs. </p>
                        <div class="cta-btn">
            <a href="contact.php" class="contact-btn">Contact <span>➜</span></a>
        </div>
                        </div>


                    </div>
                </div>
                <p style="text-align: justify;">These units are expertly designed to serve as: Security Cabins: Secure and practical units ideal for guard posts and checkpoints. Temporary Accommodations: Flexible and quick-to-deploy housing solutions for diverse temporary needs. Modular Storerooms: Adaptable storage units designed for organized and secure keeping of materials and equipment. Specialized-Purpose Units:Custom-built containers engineered for unique client functions and specific operational requirements.3. Engineering WorksOur engineering solutions are the epitome of precision and reliability, delivered by our expert team:Structural Fabrication: Impeccable fabrication of precise and robust metal structures, including beams, columns, and various other critical structural components for diverse projects.Advanced Welding & Assembly: High-level welding services for a wide range of metals and alloys, coupled with the flawless assembly of fabricated components.4.Civil WorksOur comprehensive civil engineering capabilities cover an extensive array of foundational construction requirements, ensuring solid and reliable infrastructure:Industrial & Commercial Construction: Expert construction of modern factories, commercial buildings, robust concrete structures, and other essential industrial establishments. Specialized Flooring Solutions: The skillful execution of durable and functional flooring systems, including heavy-duty industrial flooring designed for demanding environments. Site Development & Earthwork: Comprehensive land preparation, precise excavation, efficient backfilling, and overall site development services for seamless project execution.Our Commitment to ExcellenceAt Sheefa Fabrica, we're widely recognized for our unwavering commitment to excellence. We place a strong emphasis on rigorous quality control, exemplary project management, and supreme client satisfaction. Our experienced workforce, combined with an innovative approach, ensures every project is completed on time, within the stipulated budget, and to the highest global quality standards. We deeply understand our clients' unique requirements, allowing us to provide tailored solutions that significantly enhance their operational efficiency and productivity.Connect With UsAre you looking for a reliable, forward-thinking, and nationwide partner for your fabrication, engineering, or construction needs? Reach out to Sheefa Fabrication Engineering Works. Our dedicated team is eager to discuss your project in detail and provide the most suitable and effective solutions..
</p>
            </div> <!-- end container -->
        </section>
        <!-- end about-section-s3 -->


  
<div class="container">
   <div class="row">
        <div class="col-lg-4">
            <img src="assets/images/1.jpg">
         </div>

         <div class="col-lg-4">
            <img src="assets/images/2.jpg">
         </div>

         <div class="col-lg-4">
            <img src="assets/images/3.jpg">
         </div>
   </div>
</div>

    <!-- start work-process-section -->
<section class="work-process-section section-padding" style="background: #f2f2f2;">
    <div class="container">
        <div class="row">
            <div class="col col-lg-3 col-md-4">
                <div class="section-title-s4">
                    <span>Work Process</span>
                    <h2>How We Work</h2>
                </div>
            </div>
            <div class="col col-lg-8 col-md-8">
                <p>
                    At Sheefa Fabrication Engineering Works, we follow a well-structured and transparent work process to deliver durable, precise, and high-quality fabrication solutions. From planning to execution, we ensure safety, accuracy, and timely completion of every project.
                </p>
            </div>
        </div>   

        <div class="row">
            <div class="col col-xs-12">
                <div class="work-process-content">
                    <!-- Nav tabs -->
                    <div class="tablinks">
                        <ul>
                            <li class="active">
                                <a href="#tab-1" data-toggle="tab">Plan</a>
                            </li>
                            <li>
                                <a href="#tab-2" data-toggle="tab">Design</a>
                            </li>
                            <li>
                                <a href="#tab-3" data-toggle="tab">Develop</a>
                            </li>
                        </ul>
                    </div>

                    <!-- Tab panes -->
                    <div class="tab-content">

                        <!-- PLAN -->
                        <div class="tab-pane in active" id="tab-1">
                            <div class="img-holder">
                                <img src="assets/images/projects/5.jpg" alt="">
                            </div>
                            <div class="details">
                                <h3>Project Planning</h3>
                                <p>
                                    Every project begins with detailed planning and client consultation. We carefully analyze requirements, site conditions, materials, and timelines to ensure smooth execution and cost efficiency.
                                </p>
                                <div class="detail-list">
                                    <ul>
                                        <li><i class="fa fa-caret-right"></i> Understanding client requirements.</li>
                                        <li><i class="fa fa-caret-right"></i> Site inspection and measurements.</li>
                                        <li><i class="fa fa-caret-right"></i> Material and resource planning.</li>
                                    </ul>
                                    <ul>
                                        <li><i class="fa fa-caret-right"></i> Safety and quality assessment.</li>
                                        <li><i class="fa fa-caret-right"></i> Project scheduling and budgeting.</li>
                                        <li><i class="fa fa-caret-right"></i> Workflow and manpower planning.</li>
                                    </ul>
                                </div>
                            </div>
                        </div>

                        <!-- DESIGN -->
                        <div class="tab-pane fade" id="tab-2">
                            <div class="img-holder">
                               <img src="assets/images/ui.jpg" alt="">
                            </div>
                            <div class="details">
                                <h3>Design & Engineering</h3>
                                <p>
                                    Our engineering team prepares accurate designs and fabrication drawings that meet industry standards. We focus on strength, functionality, and long-term durability.
                                </p>
                                <div class="detail-list">
                                    <ul>
                                        <li><i class="fa fa-caret-right"></i> Structural and fabrication drawings.</li>
                                        <li><i class="fa fa-caret-right"></i> Customized design solutions.</li>
                                        <li><i class="fa fa-caret-right"></i> Load and safety considerations.</li>
                                    </ul>
                                    <ul>
                                        <li><i class="fa fa-caret-right"></i> Material optimization.</li>
                                        <li><i class="fa fa-caret-right"></i> Client approval before execution.</li>
                                        <li><i class="fa fa-caret-right"></i> Compliance with engineering standards.</li>
                                    </ul>
                                </div>
                            </div>
                        </div>

                        <!-- DEVELOP -->
                        <div class="tab-pane fade" id="tab-3">
                            <div class="img-holder">
                               <img src="assets/images/projects/3.jpg" alt="">
                            </div>
                            <div class="details">
                                <h3>Fabrication & Installation</h3>
                                <p>
                                    With skilled technicians and modern tools, we execute fabrication and installation with precision. Quality checks are performed at every stage to ensure flawless results.
                                </p>
                                <div class="detail-list">
                                    <ul>
                                        <li><i class="fa fa-caret-right"></i> High-quality fabrication work.</li>
                                        <li><i class="fa fa-caret-right"></i> Skilled welding and finishing.</li>
                                        <li><i class="fa fa-caret-right"></i> Strict quality control checks.</li>
                                    </ul>
                                    <ul>
                                        <li><i class="fa fa-caret-right"></i> On-site installation support.</li>
                                        <li><i class="fa fa-caret-right"></i> Timely project completion.</li>
                                        <li><i class="fa fa-caret-right"></i> Final inspection and handover.</li>
                                    </ul>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>             
    </div>
</section>
<!-- end work-process-section -->


        <!-- start cta-section-s2 -->
        <section class="cta-section-s2">
            <div class="container">
                <div class="row">
                    <div class="col col-xs-12">
                        <div class="cta-text">
                            <h3>Get the Best Fabrication Solutions for Your Project.</h3>
                            <a href="#" class="theme-btn-s2">Contact Us</a>
                        </div>
                    </div>
                </div>
            </div> <!-- end container -->
        </section>   
        <!-- end cta-section-s2 -->


    


 


   


       
        <!-- start news-letter-section -->
      <?php include('footer.php');?>
    </div>
    <!-- end of page-wrapper -->



    <!-- All JavaScript files
    ================================================== -->
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>

    <!-- Plugins for this template -->
    <script src="assets/js/jquery-plugin-collection.js"></script>

    <!-- Google map api -->
    <script src="https://maps.googleapis.com/maps/api/js?key"></script>

    <!-- Custom script for this template -->
    <script src="assets/js/script.js"></script>
</body>

<!-- Mirrored from html.themexriver.com/clinkers/about.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 12 Dec 2025 05:08:20 GMT -->
</html>
