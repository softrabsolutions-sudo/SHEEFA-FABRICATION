<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Meta Tags -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="author" content="themexriver">

    <!-- Page Title -->
    <title> Fabrication Service </title>

    <!-- Icon fonts -->
    <link href="assets/css/font-awesome.min.css" rel="stylesheet">
 <link rel="icon" type="image/x-icon" href="assets/images/sheefa-120x120.jpg">
    <!-- Bootstrap core CSS -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/7.0.1/css/all.min.css" />
    <!-- Plugins for this template -->
    <link href="assets/css/animate.css" rel="stylesheet">
    <link href="assets/css/owl.carousel.css" rel="stylesheet">
    <link href="assets/css/owl.theme.css" rel="stylesheet">
    <link href="assets/css/slick.css" rel="stylesheet">
    <link href="assets/css/slick-theme.css" rel="stylesheet">
    <link href="assets/css/owl.transitions.css" rel="stylesheet">
    <link href="assets/css/jquery.fancybox.css" rel="stylesheet">
    <link href="assets/css/magnific-popup.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="assets/css/style.css" rel="stylesheet">

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body>

    <!-- start page-wrapper -->
    <div class="page-wrapper">

        <!-- start preloader -->
        <div class="preloader">
            <div class="preloader-inner">
                <img src="assets/images/preloader.gif" alt>
            </div>
        </div>
        <!-- end preloader -->
<?php include('header.php');?>

        <!-- start page-title -->
        <section class="page-title">
            <div class="container">
                <div class="row">
                    <div class="col col-xs-12">
                        <div class="title-breadcrumb">
                            <h2>Service</h2>
                            <ol class="breadcrumb">
                                <li><a href="index.html">Home</a></li>
                                <li>Fabrication Service</li>
                            </ol>
                        </div>
                    </div>
                </div> <!-- end row -->
            </div> <!-- end container -->
        </section>        
        <!-- end page-title -->


        <!-- start service-singel-section -->
        <section class="service-singel-section section-padding">
            <div class="container">
                <div class="row">
                    <div class="col col-md-8 col-md-push-4">
                        <div class="service-single-content">
                            <div>
                                <!-- <img src="assets/images/hh.png"  class="img-fluid"> -->
                                <div class="slider">
<div class="slides" id="slides">
<div class="slide"><img src="assets/images/ui.jpg" alt="slide 1" class="img-fluid"></div>
<div class="slide"><img src="assets/images/projects/5.jpg" alt="slide 2"></div>
<div class="slide"><img src="assets/images/projects/4.jpg" alt="slide 3"></div>
<div class="slide"><img src="assets/images/projects/2.jpg" alt="slide 4"></div>
<div class="slide"><img src="assets/images/peb-structures-fabrication-service-500x500.jpg" alt="slide 5"></div>
<div class="slide"><img src="assets/images/industrial-shed-500x500.jpg" alt="slide 6"></div>
</div>


<button class="nav1 prev" onclick="prevSlide()">❮</button>
<button class="nav1 next" onclick="nextSlide()">❯</button>


<div class="dots" id="dots">
<span class="dot active" onclick="goToSlide(0)"></span>
<span class="dot" onclick="goToSlide(1)"></span>
<span class="dot" onclick="goToSlide(2)"></span>
<span class="dot" onclick="goToSlide(3)"></span>
<span class="dot" onclick="goToSlide(4)"></span>
<span class="dot" onclick="goToSlide(5)"></span>
<span class="dot" onclick="goToSlide(6)"></span>
</div>
</div>
                            </div>
                            <div class="title">
                                <h3>Roofing Sheets Installation Services ₹ 15/sq ft</h3>
                                <div class="download">
                                    <a href="assets/images/sheefa-fabrication-engineering-works.pdf"><i class="fa fa-file-word-o"></i> Download Brochure</a>
                                   
                                </div>
                            </div>


                            <div class="details">
                                <p>GI Roof Sheet Installation ServicesOur company provides GI roof sheet installation services that help secure, beautify, and make your building durable. Our team consists of experienced and trained professionals who provide the best roofing solutions for your needs.Our Services GI Roof Sheet Installation Roofing Solutions Waterproofing Solutions Cladding Solutions Insulation SolutionsOur Roofing Series Standing Seam Roofing Corrugated Roofing Trapezoidal Roofing Screw Down Roofing Purlin Roofing Our Specialties High-quality services- Experienced and trained team Complete satisfaction guarantee Timely and budget-friendly work</p>

<ul>
  <li><i class="fa fa-plus"></i> Custom steel & MS fabrication for industrial and commercial needs</li>
  <li><i class="fa fa-plus"></i> Precision welding, cutting, bending & structural works</li>
  <li><i class="fa fa-plus"></i> Reliable project execution with quality materials & skilled manpower</li>
</ul>

<p><strong>Sheefa Fabrication Engineering Works</strong> is a trusted name in metal fabrication, delivering durable and cost‑effective engineering solutions. We specialize in mild steel, stainless steel, and structural fabrication for factories, warehouses, commercial buildings, and infrastructure projects. Our focus is on strength, safety, and timely delivery while maintaining high workmanship standards.</p>

<h4>Why Choose Sheefa Fabrication Engineering Works</h4>

<p>With experienced technicians and modern fabrication tools, we ensure accurate measurements, clean welding finishes, and long‑lasting results. From design support to final installation, we handle each project with professionalism and attention to detail, making us a dependable partner for all types of fabrication engineering requirements.</p>

                                <a href="#" class="theme-btn-s2">Contact us</a>
                            </div>
                        </div> <!-- end service content -->
                    </div> <!-- end col -->
                    
                    <div class="col col-md-4 col-md-pull-8">
                        <div class="service-single-sidebar">
                            <div class="services-link-widget widget">
                                <ul>
                                   <li><a href="fabrication-service.php">Fabrication Service</a></li>
                                    <li><a href="project-sigle.html">Prefabricated Structure</a></li>
                                    <li><a href="team.html">Roofing Sheet</a></li>
                                    <li><a href="testimonials.html">Ventilation Fan</a></li>
                                    <li><a href="faq.html">Portable Cabin</a></li>
                                     <li><a href="faq.html">Prefabricated Factory Shed</a></li>
                                      <li><a href="faq.html">Industrial Shed Fabrication</a></li>
                                </ul>
                            </div>


                            <div class="download-brocher-widget widget">
                                <a href="assets/images/sheefa-fabrication-engineering-works.pdf"><i class="fa fa-file-pdf-o"></i> Download brochure</a>
                            </div>
                            <div class="widget contact-widget">
                                <h3>Contact us for help?</h3>
                                <p>Tell us what you need, and we'll help you get quotes</p>
                                <a href="tel:+91 8043842442"><i class="fa-solid fa-phone"></i>&nbsp;&nbsp;+91 8043842442</a>
                            </div>

                            <style>
                                @media (max-width: 767px) {
    .section-padding {
        padding: 1px 0 !important;
    }
}


.faq-section{
margin-bottom:40px;
}


.faq-header h2{
font-size:32px;
margin-bottom:10px;
color:#222;
}


.faq-header p{
color:#666;
font-size:16px;
}


.faq-item{
border:1px solid #e5e5e5;
border-radius:6px;
margin-bottom:15px;
overflow:hidden;
}


.faq-question{
background:#f9fafb;
padding:10px 20px;
font-size:14px;
font-weight:600;
cursor:pointer;
display:flex;
justify-content:space-between;
align-items:center;
}


.faq-question span{
font-size:22px;
transition:0.3s;
}


.faq-item.active .faq-question span{
transform:rotate(45deg);
}


.faq-answer{
max-height:0;
overflow:hidden;
transition:max-height 0.4s ease;
background:#fff;
}


.faq-answer p{
padding:15px 20px;
color:#555;
font-size:15px;
line-height:1.6;
}


/* Responsive */
@media(max-width:600px){
.faq-header h2{
font-size:24px;
}
}
                            </style>

<div class="table-wrap" style="margin-top: 1em;">
<table>
<tr>
<td>Roofing Material</td>
<td>Polycarbonate</td>
</tr>
<tr>
<td>Shed Material</td>
<td>Galvanized steel</td>
</tr>
<tr>
<td>Color</td>
<td>Blue</td>
</tr>
<tr>
<td>Payment Mode</td>
<td>Online / Offline</td>
</tr>
<tr>
<td>Service Mode</td>
<td>Offline</td>
</tr>
<tr>
<td>Service Location</td>
<td>India</td>
</tr>
</table>
</div>

<section class="faq-section">
<div class="faq-container">
<div class="faq-header">
<h2>Frequently Asked Questions</h2>
<p>Sheefa Fabrication Engineering Works</p>
</div>


<div class="faq-item">
<div class="faq-question">What services does Sheefa Fabrication Engineering Works provide? <span>+</span></div>
<div class="faq-answer">
<p>We specialize in fabrication work including industrial sheds, roofing structures, steel fabrication, gates, grills, and custom engineering solutions.</p>
</div>
</div>


<div class="faq-item">
<div class="faq-question">Do you provide custom fabrication solutions? <span>+</span></div>
<div class="faq-answer">
<p>Yes, we offer fully customized fabrication and engineering solutions based on client requirements and site conditions.</p>
</div>
</div>


<div class="faq-item">
<div class="faq-question">Which materials do you use for fabrication? <span>+</span></div>
<div class="faq-answer">
<p>We use high-quality materials such as galvanized steel, mild steel, polycarbonate sheets, and other durable metals.</p>
</div>
</div>


<div class="faq-item">
<div class="faq-question">Do you provide installation services? <span>+</span></div>
<div class="faq-answer">
<p>Yes, our experienced team handles complete fabrication and on-site installation services.</p>
</div>
</div>


<div class="faq-item">
<div class="faq-question">What locations do you serve? <span>+</span></div>
<div class="faq-answer">
<p>We primarily serve clients across India. For specific locations, please contact us directly.</p>
</div>
</div>


</div>
</section>

                        </div>
                    </div>
                </div> <!-- end row -->
            </div> <!-- end container -->
        </section>
        <!-- end service-single-section -->      


        <!-- start news-letter-section -->
  
    </div>
    <!-- end of page-wrapper -->

<?php include('footer.php');?>

    <!-- All JavaScript files
    ================================================== -->
    <script src="assets/js/jquery.min.js"></script>
    <script>
        let currentIndex = 0;
const slides = document.getElementById('slides');
const dots = document.querySelectorAll('.dot');
const totalSlides = 4;


function updateSlider() {
slides.style.transform = `translateX(-${currentIndex * 100}%)`;
dots.forEach(dot => dot.classList.remove('active'));
dots[currentIndex].classList.add('active');
}


function nextSlide() {
currentIndex = (currentIndex + 1) % totalSlides;
updateSlider();
}


function prevSlide() {
currentIndex = (currentIndex - 1 + totalSlides) % totalSlides;
updateSlider();
}


function goToSlide(index) {
currentIndex = index;
updateSlider();
}


// Auto slide
setInterval(nextSlide, 4000);


const faqItems = document.querySelectorAll('.faq-item');


faqItems.forEach(item => {
const question = item.querySelector('.faq-question');
question.addEventListener('click', () => {
faqItems.forEach(i => {
if(i !== item){
i.classList.remove('active');
i.querySelector('.faq-answer').style.maxHeight = null;
}
});


item.classList.toggle('active');
const answer = item.querySelector('.faq-answer');


if(item.classList.contains('active')){
answer.style.maxHeight = answer.scrollHeight + 'px';
} else {
answer.style.maxHeight = null;
}
});
});
    </script>
    <script src="assets/js/bootstrap.min.js"></script>

    <!-- Plugins for this template -->
    <script src="assets/js/jquery-plugin-collection.js"></script>

    <!-- Custom script for this template -->
    <script src="assets/js/script.js"></script>
</body>
</html>
