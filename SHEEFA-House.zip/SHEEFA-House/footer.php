        <!-- start contact-info-map-section -->
        <section class="contact-info-map-section">
            <div class="content">
                <div class="left-col">
                   <iframe src="https://www.google.com/maps/embed?pb=!1m16!1m12!1m3!1d3721.8793172056285!2d72.86014742503393!3d21.117377030554213!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!2m1!1sFlat%20No.201%2C%20Maasarat%20Park%20Apartment%2C%20Navab%20Residency%20UNN%2C%20Surat-394210%2C%20Gujarat%2C%20India!5e0!3m2!1sen!2sin!4v1765698449710!5m2!1sen!2sin" width="100%" height="390" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
                </div>
                <div class="right-col">
                    <div class="inner">
                        <div class="title-text">
                            <h3>Drop us a line</h3>
                            <p>For any kind of query, contact us with the details below.</p>
                        </div>
                        <div class="contact-info">
                            <ul>
                                <li><i class="fa fa-phone"></i> +91 8043842442</li>
                                <li><i class="fa fa-envelope"></i> Harsha Navghare (Manager)</li>
                                <li><i class="fa fa-home"></i> Flat No.201, Maasarat Park Apartment, Navab Residency UNN, Surat-394210, Gujarat, India</li>
                                  <li><i class="fa fa-envelope"></i> <strong>Branch Office</strong>Harsha Navghare
platinum plaza A122
India</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div> <!-- end content -->
        </section>
        <!-- end contact-info-map-section -->


        <!-- start news-letter-section -->
    <section class="cta-section1">
    <div class="cta-container">
        <div class="cta-left">
            <img src="assets/images/sheefa-120x120.jpg" alt="" style="width: 100px;">
        </div>

        <div class="cta-text">
            <h3>Get the Best Fabrication Solutions for Your Project</h3>
        </div>

        <div class="cta-btn">
            <a href="#" class="contact-btn">Contact <span>➜</span></a>
        </div>
    </div>
</section>


        <!-- end news-letter-section -->


        <!-- start site-footer -->
        <footer class="site-footer">
            <div class="upper-footer">
                <div class="container">
                    <div class="row">
                        <div class="col col-md-3 col-sm-6">
                            <div class="widget about-widget">
                                <div class="footer-logo">Information</div>
                                <p>Sheefa Fabrication Engineering Works: Leading Industrial Fabrication & Engineering Solutions Across IndiaEstablished in 2012, Sheefa Fabrication Engineering Works is a premier provider of industrial fabrication, advanced engineering, and comprehensive construction services</p>
                                <ul>
                                    <li><a href="#"><i class="fa-brands fa-facebook"></i></a></li>
                                    <li><a href="#"><i class="fa-brands fa-instagram"></i></a></li>
                                    <li><a href="#"><i class="fa-brands fa-x-twitter"></i></a></li>
                                  
                                </ul>
                            </div>
                        </div>

                        <div class="col col-md-3 col-sm-6">
                            <div class="widget services-widget">
                                <h3>Services</h3>
                                <ul>
                                    <li><a href="#"><i class="fa fa-angle-right"></i> Fabrication Service</a></li>
                                    <li><a href="#"><i class="fa fa-angle-right"></i> Prefabricated Structure</a></li>
                                    <li><a href="#"><i class="fa fa-angle-right"></i> Roofing Sheet</a></li>
                                    <li><a href="#"><i class="fa fa-angle-right"></i> Ventilation Fan</a></li>
                                    <li><a href="#"><i class="fa fa-angle-right"></i> Portable Cabin</a></li>
                                </ul>
                            </div>
                        </div>

                        <div class="col col-md-3 col-sm-6">
                            <div class="widget services-widget">
                                <h3>Quick Links</h3>
                                <ul>
                                    <li><a href="#"><i class="fa fa-angle-right"></i> Home</a></li>
                                    <li><a href="#"><i class="fa fa-angle-right"></i> About Us</a></li>
                                    <li><a href="#"><i class="fa fa-angle-right"></i> Service</a></li>
                                    <li><a href="#"><i class="fa fa-angle-right"></i> Gallery</a></li>
                                    <li><a href="#"><i class="fa fa-angle-right"></i> Contact Us</a></li>
                                </ul>
                            </div>
                        </div>

                        <div class="col col-md-3 col-sm-6">
                             <div class="widget services-widget">
                                <h3>Google Maps</h3>
                              <iframe src="https://www.google.com/maps/embed?pb=!1m16!1m12!1m3!1d7443.869440577551!2d72.86026818597084!3d21.115168592241723!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!2m1!1sFlat%20No.201%2C%20Maasarat%20Park%20Apartment%2C%20Navab%20Residency%20UNN%2C%20Surat-394210%2C%20Gujarat%2C%20India!5e0!3m2!1sen!2sin!4v1765523539319!5m2!1sen!2sin" width="100%" height="250" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
                            </div>
                        </div>
                    </div>
                </div> <!-- end container -->
            </div> <!-- end upper-footer -->
            <div class="copyright-info">
                <div class="container">
                    <p>© 2025 Sheefa Fabrication Engineering Works. All Rights Reserved.</a></p>
                </div>
            </div>
        </footer>
        <!-- end site-footer -->