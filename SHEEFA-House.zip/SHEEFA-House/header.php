
        <!-- Start header -->
        <header id="header" class="site-header header-style-1">

            <div class="topbar">
                <marquee behavior="scroll" direction="left" scrollamount="8" style="
    background: #ff5e14; 
    color:#fff; 
    padding:10px 0;
    font-size:18px;
    font-weight:600;">
    Sheefa Fabrication Engineering Works Quality Fabrication, Fabrication Service , Prefabricated Structure,
    Roofing Sheet, & Ventilation Fan Services.
</marquee>
                <div class="container">
                    <div class="row">
                        <div class="col col-sm-6">
                            <div class="office-hour">
                                <ul>
                                    <li><i class="fa fa-clock-o"></i> Monday - friday : 8:00 AM to 7:00 PM</li>
                                </ul>
                            </div>
                        </div>
                        <div class="col col-sm-6">
                            <div class="contact-info">
                                <ul>
                                    <li><i class="fa fa-phone"></i>+91 8043842442</li>
                                    <li><i class="fa fa-envelope"></i> info@sheefafabricationengineeringworks.con</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div> <!-- end container -->
            </div> <!-- end topbar -->

            <nav class="navigation navbar navbar-default">
                <div class="container">
                    <div class="navbar-header">
                        <button type="button" class="open-btn">
                            <span class="sr-only">Toggle navigation</span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                        </button>
                        <a class="navbar-brand" href="index.php"><img src="assets/images/sheefa-120x120.jpg" alt="" style="width: 100px;"></a>
                    </div>
                    <div id="navbar" class="navbar-collapse collapse navbar-right navigation-holder">
                        <button class="close-navbar"><i class="fa fa-close"></i></button>
                        <ul class="nav navbar-nav">
                            <li class="menu-item-has-children">
                                <a href="index.php">Home</a>
                            </li>
                            <li><a href="about.php">About</a></li>
                          <!--   <li class="menu-item-has-children">
                                <a href="#">Services</a>
                                <ul class="sub-menu">
                                    <li><a href="services.html">Services</a></li>
                                    <li><a href="service-single.html">Power and energy</a></li>
                                    <li><a href="oil-lubricant.html">Oil and lubricant</a></li>
                                    <li><a href="meterial-engineering.html">Meterial engineering</a></li>
                                    <li><a href="mechanical-engineering.html">Mechanical engineering</a></li>
                                    <li><a href="chemical-research.html">Chemical research</a></li>
                                    <li><a href="alternate-energy.html">Alternate energy</a></li>
                                    <li><a href="agricultural-processing.html">Agricultural processing</a></li>
                                </ul>
                            </li> -->
                            <li class="menu-item-has-children">
                                <a href="#">Product & Service</a>
                                  <ul class="sub-menu">
                                    <li><a href="fabrication-service.php">Fabrication Service</a></li>
                                    <li><a href="prefabricated-structure.php">Prefabricated Structure</a></li>
                                    <li><a href="roofing-sheet.php">Roofing Sheet</a></li>
                                    <li><a href="roofing-sheet-installations.php">Roofing Sheet Installations</a></li>
                                    <li><a href="portable-cabin.php">Portable Cabin</a></li>
                                     <li><a href="prefabricated-factory-shed.php">Prefabricated Factory Shed</a></li>
                                      <li><a href="industrial-shed-fabrication.php">Industrial Shed Fabrication</a></li>
                                </ul>
                            </li>
                            <li class="menu-item-has-children">
                                <a href="#">Gallery</a>
                            </li>
                            <li><a href="#">Contact</a></li>
                        </ul>
                    </div><!-- end of nav-collapse -->
                    <div class="request-quote">
                        <a href="#">Request Quote</a>
                    </div>
                </div><!-- end of container -->
            </nav>
        </header>
        <!-- end of header -->