<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Meta Tags -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="author" content="themexriver">

    <!-- Page Title -->
    <title> Sheefa Fabrication Engineering Works </title>
     <link rel="icon" type="image/x-icon" href="assets/images/sheefa-120x120.jpg">

    <!-- Icon fonts -->
    <link href="assets/css/font-awesome.min.css" rel="stylesheet">

    <!-- Bootstrap core CSS -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/7.0.1/css/all.min.css" />
    <!-- Plugins for this template -->
    <link href="assets/css/animate.css" rel="stylesheet">
    <link href="assets/css/owl.carousel.css" rel="stylesheet">
    <link href="assets/css/owl.theme.css" rel="stylesheet">
    <link href="assets/css/slick.css" rel="stylesheet">
    <link href="assets/css/slick-theme.css" rel="stylesheet">
    <link href="assets/css/owl.transitions.css" rel="stylesheet">
    <link href="assets/css/jquery.fancybox.css" rel="stylesheet">
    <link href="assets/css/magnific-popup.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="assets/css/style.css" rel="stylesheet">

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body>

    <!-- start page-wrapper -->
    <div class="page-wrapper">

        <!-- start preloader -->
        <div class="preloader">
            <div class="preloader-inner">
                <img src="assets/images/preloader.gif" alt>
            </div>
        </div>
        <!-- end preloader -->
<?php include('header.php');?>


        <!-- start of hero -->   
        <section class="hero hero-slider-wrapper hero-style-1">
            <div class="hero-slider">
                <div class="slide">
                    <img src="assets/images/slider/banner-7.png" alt class="slider-bg">
                    <div class="container">
                        <div class="row">
                            <div class="col col-lg-6 col-md-8 col-sm-10 slide-caption">
                                <h3 class="text-white" style="color: #000; background: #fff; display: inline-block; padding: 7px 13px; border-radius: 100px;">Welcome To</h3>
                                <h2><span>Sheefa Fabrication</span>Engineering Works</h2>
                                <p>is a trusted name in high-quality metal fabrication, custom engineering solutions, and durable structural designs</p>
                                <div class="btns">
                                    <a href="#" class="theme-btn">Our Service</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="slide">
                    <img src="assets/images/slider/2.png" alt class="slider-bg">
                    <div class="container">
                        <div class="row">
                            <div class="col col-lg-6 col-md-8 col-sm-10 slide-caption">
                                  <h3 class="text-white" style="color: #000; background: #fff; display: inline-block; padding: 7px 13px; border-radius: 100px;">Welcome To</h3>
                                <h2><span>Portable </span>Office Cabin</h2>
                                <p>are a smart and convenient solution for businesses that need flexible workspace without the cost and time of permanent construction</p>
                                <div class="btns">
                                    <a href="#" class="theme-btn">Our Services</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="slide">
                    <img src="assets/images/slider/5.jpg" alt class="slider-bg">
                    <div class="container">
                        <div class="row">
                            <div class="col col-lg-6 col-md-8 col-sm-10 slide-caption">
                                   <h3 class="text-white" style="color: #000; background: #fff; display: inline-block; padding: 7px 13px; border-radius: 100px;">Welcome To</h3>
                                <h2><span>Color Coated </span>Roofing Sheet</h2>
                                <p>are a modern and durable roofing solution designed to provide long-lasting protection with an attractive appearance</p>
                                <div class="btns">
                                    <a href="#" class="theme-btn">Our Industries</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- end of hero slider -->











        <!-- start cta-section -->
        <section class="cta-section" style="box-shadow: rgba(100, 100, 111, 0.2) 0px 7px 29px 0px;">
            <div class="container">
                <div class="row">
                    <div class="col col-xs-12">
                        <div class="cta-text">
                            <h3 style="color: #000 !important; text-align: start;">Sheefa Fabrication Engineering Works provides innovative product solutions for sustainable progress.</h3>
                            <a href="#" class="theme-btn-s2">Contact Us</a>
                        </div>
                    </div>
                </div>
            </div> <!-- end container -->
        </section>
        <!-- end cta-section -->
  <section class="about-section-s3 section-padding">
            <div class="container">
                <div class="row">
                    <div class="col col-md-6">
                        <div class="about-img">
                            <img src="assets/images/product-jpeg-500x500.jpg" alt>

                        </div>
                    </div>
                    <div class="col col-md-6">
                        <div class="about-text">
                            <div class="title">
                                <span>About Us </span>
                                <h2>Sheefa Fabrication Engineering Works</h2>
                            </div>
                            <p>Sheefa Fabrication Engineering Works: Leading Industrial Fabrication & Engineering Solutions Across IndiaEstablished in 2012, Sheefa Fabrication Engineering Works is a premier provider of industrial fabrication, advanced engineering, and comprehensive construction services. Headquartered in Surat, Gujarat, we're dedicated to delivering unparalleled quality, efficiency, and tailored solutions to our esteemed clients across India. Our exceptional expertise, state-of-the-art technology, and unwavering commitment to quality make us a distinguished leader in the industry. </p>


                            <div class="signature">
                              <!-- From Uiverse.io by SelfMadeSystem --> 
<button class="btn btn-primary">
  <span class="btn-txt">Read More</span>
  <kbd class="btn-kbd">></kbd>

</button>

                            </div>
                        </div>



                        <div class="fun-fact">
                            <div class="fun-fact-grids start-count">
                                <div class="grid">
                                    <div class="icon">
                                        <img src="assets/images/fun-fact/icon-1.html" alt>
                                    </div>
                                    <h3>
                                        <span class="counter" data-count="1200">00</span><span>+</span>
                                    </h3>
                                    <p>Completed Fabrication Projects</p>
                                </div>

                                <div class="grid">
                                    <div class="icon">
                                        <img src="assets/images/fun-fact/icon-2.html" alt>
                                    </div>
                                    <h3>
                                        <span class="counter" data-count="900">00</span><span>+</span>
                                    </h3>
                                    <p>Industrial & Commercial Clients</p>
                                </div>

                                <div class="grid">
                                    <div class="icon">
                                        <img src="assets/images/fun-fact/icon-3.html" alt>
                                    </div>
                                    <h3>
                                        <span class="counter" data-count="1000">00</span><span>+</span>
                                    </h3>
                                    <p>Customized Fabrication Solutions</p>
                                </div>
                            </div> 
                        </div>
                    </div>
                </div>













                <section class="sheefa-business-info">
    <div class="container">

        <div class="sbi-grid">

            <div class="sbi-item">
                <div class="sbi-icon"><i class="fa-solid fa-hand-holding-heart"></i></div>
                <div>
                    <h4>Nature of Business</h4>
                    <p>Service Provider and Others</p>
                </div>
            </div>

            <div class="sbi-item">
                <div class="sbi-icon"><i class="fa-solid fa-scale-balanced"></i></div>
                <div>
                    <h4>Legal Status of Firm</h4>
                    <p>Proprietorship</p>
                </div>
            </div>

            <div class="sbi-item">
                <div class="sbi-icon"><i class="fa-solid fa-chart-line"></i></div>
                <div>
                    <h4>Annual Turnover</h4>
                    <p>0 - 40 L</p>
                </div>
            </div>

            <div class="sbi-item">
                <div class="sbi-icon"><i class="fa-solid fa-building"></i></div>
                <div>
                    <h4>GST Registration Date</h4>
                    <p>12-03-2021</p>
                </div>
            </div>

            <div class="sbi-item">
                <div class="sbi-icon"><i class="fa-solid fa-people-group"></i></div>
                <div>
                    <h4>Total Employees</h4>
                    <p>11 to 25 People</p>
                </div>
            </div>

            <div class="sbi-item">
                <div class="sbi-icon"><i class="fa-solid fa-file-invoice"></i></div>
                <div>
                    <h4>GST Number</h4>
                    <p>24EKMPS7749G1ZG</p>
                </div>
            </div>

        </div>

    </div>
</section>

            </div> <!-- end container -->
        </section>

     
        <!-- start services-section-s2 -->
     
        <!-- start services-section-s2 -->
        <section class="services-section-s2 section-padding">
            <div class="container">
                <div class="row">
                    <div class="col col-lg-8 col-lg-offset-2 col-sm-10 col-sm-offset-1">
                        <div class="section-title">
                            <h2>Our Service</h2>
                            <p>Sheefa Fabrication Engineering Works offers a complete range of high-quality fabrication services designed to meet the needs of residential, commercial, and industrial clients.</p>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col col-xs-12">
                        <div class="services-grids services-slider-s2">
                            <div class="grid">
                                <div class="box">
                                    <div class="service-title">
                                        <div class="icon"><img src="assets/images/services/laundry-service.png" style="width: 42px;"></div>
                                        <h3>Fabrication Service</h3>
                                    </div>
                                    <p>GI Roof Sheet Installation ServicesOur company provides GI roof sheet installation.</p>
                                    <div class="more">
                                        <a href="#">Read More</a>
                                    </div>
                                </div>
                                <div class="box">
                                    <div class="service-title">
                                        <div class="icon"><img src="assets/images/services/structure.png" style="width: 42px;"></div>
                                        <h3>Prefabricated Structure</h3>
                                    </div>
                                    <p>Pioneers in the industry, we offer Prefabricated Industrial Buildings.</p>
                                    <div class="more">
                                        <a href="#">Read More</a>
                                    </div>
                                </div>
                                <div class="box">
                                    <div class="service-title">
                                        <div class="icon"><img src="assets/images/services/sheet.png" style="width: 42px;"></div>
                                        <h3>Roofing Sheet</h3>
                                    </div>
                                    <p>Leading Wholesaler of Colour Coated Roofing Sheet Fixing Service and Color.</p>
                                    <div class="more">
                                        <a href="#">Read More</a>
                                    </div>
                                </div>
                                <div class="box">
                                    <div class="service-title">
                                        <div class="icon"><img src="assets/images/services/fan.png" style="width: 42px;"></div>
                                        <h3>Ventilation Fan</h3>
                                    </div>
                                    <p>Wholesaler of a wide range of products which include Industrial Turbo Air Ventilators.
</p>
                                    <div class="more">
                                        <a href="#">Read More</a>
                                    </div>
                                </div>
                                <div class="box">
                                    <div class="service-title">
                                        <div class="icon"><img src="assets/images/services/cabin.png" style="width: 42px;"></div>
                                        <h3>Portable Cabin</h3>
                                    </div>
                                    <p>We are a leading Wholesaler of Portable Accommodation Cabin, Portable Container Farmhouse.</p>
                                    <div class="more">
                                        <a href="#">Read More</a>
                                    </div>
                                </div>
                                <div class="box">
                                    <div class="service-title">
                                        <div class="icon"><img src="assets/images/services/factory.png" style="width: 42px;"></div>
                                        <h3>Prefabricated Factory Shed</h3>
                                    </div>
                                    <p>Offering you a complete choice of products which include Prefabricated Industrial Shed</p>
                                    <div class="more">
                                        <a href="#">Read More</a>
                                    </div>
                                </div>
                            </div>
                            <div class="grid">
                              <!--   <div class="box">
                                    <div class="service-title">
                                        <div class="icon"><img src="assets/images/services/icon-1.html" alt></div>
                                        <h3>Mechanical Engineering</h3>
                                    </div>
                                    <p>Excepteur sint occaecat cupidatat non proi dent, sunt in culpa qui officia..</p>
                                    <div class="more">
                                        <a href="#">Read More</a>
                                    </div>
                                </div> -->
                              <!--   <div class="box">
                                    <div class="service-title">
                                        <div class="icon"><img src="assets/images/services/icon-2.html" alt></div>
                                        <h3>Automobile Services</h3>
                                    </div>
                                    <p>Excepteur sint occaecat cupidatat non proi dent, sunt in culpa qui officia..</p>
                                    <div class="more">
                                        <a href="#">Read More</a>
                                    </div>
                                </div> -->
                               <!--  <div class="box">
                                    <div class="service-title">
                                        <div class="icon"><img src="assets/images/services/icon-3.html" alt></div>
                                        <h3>Bridge Construction</h3>
                                    </div>
                                    <p>Excepteur sint occaecat cupidatat non proi dent, sunt in culpa qui officia..</p>
                                    <div class="more">
                                        <a href="#">Read More</a>
                                    </div>
                                </div> -->
                              <!--   <div class="box">
                                    <div class="service-title">
                                        <div class="icon"><img src="assets/images/services/icon-4.html" alt></div>
                                        <h3>Steel Industry</h3>
                                    </div>
                                    <p>Excepteur sint occaecat cupidatat non proi dent, sunt in culpa qui officia..</p>
                                    <div class="more">
                                        <a href="#">Read More</a>
                                    </div>
                                </div> -->
                                <!-- <div class="box">
                                    <div class="service-title">
                                        <div class="icon"><img src="assets/images/services/icon-5.html" alt></div>
                                        <h3>Knitwear Products</h3>
                                    </div>
                                    <p>Excepteur sint occaecat cupidatat non proi dent, sunt in culpa qui officia..</p>
                                    <div class="more">
                                        <a href="#">Read More</a>
                                    </div>
                                </div> -->
                               <!--  <div class="box">
                                    <div class="service-title">
                                        <div class="icon"><img src="assets/images/services/icon-6.html" alt></div>
                                        <h3>Timber Production</h3>
                                    </div>
                                    <p>Excepteur sint occaecat cupidatat non proi dent, sunt in culpa qui officia..</p>
                                    <div class="more">
                                        <a href="#">Read More</a>
                                    </div>
                                </div> -->
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col col-xs-12">
                        <p class="view-all-services"> Click here to view <a href="#">All Services <i class="fa fa-long-arrow-right"></i></a></p>
                    </div>
                </div>                
            </div> <!-- end container -->
        </section>
        <!-- end services-section-s2 -->
        <!-- end services-section-s2 -->

<!-- Work Process Section -->
<section id="work-process" class="work-process-section" style="padding: 80px 0; background-color: #f8f9fa; font-family: Arial, sans-serif;">
  <div class="container" style="max-width: 1200px; margin: 0 auto;">
    <!-- Section Header -->
    <div class="section-header" style="text-align: center; margin-bottom: 60px;">
      <h2 style="font-size: 36px; color: #222; margin-bottom: 10px;">Our Work Process</h2>
      <p style="font-size: 18px; color: #555;">At <strong>Sheefa Fabrication Engineering Works</strong>, we follow a structured process to ensure quality, precision, and timely delivery.</p>
    </div>

    <!-- Process Steps -->
    <div class="process-steps">
      
      <!-- Step 1 -->
      <div class="step" style="flex: 1 1 30%; background: #fff; padding: 30px; border-radius: 12px; box-shadow: 0 8px 20px rgba(0,0,0,0.1); text-align: center;">
        <div class="step-number" style="font-size: 28px; font-weight: bold; color: #ff6600; margin-bottom: 15px;">01</div>
        <h3 style="font-size: 22px; color: #222; margin-bottom: 10px;">Consultation & Planning</h3>
        <p style="color: #555;">We understand your requirements and provide professional advice for the best fabrication solutions.</p>
      </div>

      <!-- Step 2 -->
      <div class="step" style="flex: 1 1 30%; background: #fff; padding: 30px; border-radius: 12px; box-shadow: 0 8px 20px rgba(0,0,0,0.1); text-align: center;">
        <div class="step-number" style="font-size: 28px; font-weight: bold; color: #ff6600; margin-bottom: 15px;">02</div>
        <h3 style="font-size: 22px; color: #222; margin-bottom: 10px;">Design & Material Selection</h3>
        <p style="color: #555;">Our engineers create precise designs and choose high-quality materials for durable results.</p>
      </div>

      <!-- Step 3 -->
      <div class="step" style="flex: 1 1 30%; background: #fff; padding: 30px; border-radius: 12px; box-shadow: 0 8px 20px rgba(0,0,0,0.1); text-align: center;">
        <div class="step-number" style="font-size: 28px; font-weight: bold; color: #ff6600; margin-bottom: 15px;">03</div>
        <h3 style="font-size: 22px; color: #222; margin-bottom: 10px;">Fabrication & Manufacturing</h3>
        <p style="color: #555;">Using advanced machinery, we fabricate components with precision and care.</p>
      </div>

      <!-- Step 4 -->
      <div class="step" style="flex: 1 1 30%; background: #fff; padding: 30px; border-radius: 12px; box-shadow: 0 8px 20px rgba(0,0,0,0.1); text-align: center;">
        <div class="step-number" style="font-size: 28px; font-weight: bold; color: #ff6600; margin-bottom: 15px;">04</div>
        <h3 style="font-size: 22px; color: #222; margin-bottom: 10px;">Quality Check & Inspection</h3>
        <p style="color: #555;">Every product undergoes rigorous testing to ensure it meets our high-quality standards.</p>
      </div>

      <!-- Step 5 -->
      <div class="step" style="flex: 1 1 30%; background: #fff; padding: 30px; border-radius: 12px; box-shadow: 0 8px 20px rgba(0,0,0,0.1); text-align: center;">
        <div class="step-number" style="font-size: 28px; font-weight: bold; color: #ff6600; margin-bottom: 15px;">05</div>
        <h3 style="font-size: 22px; color: #222; margin-bottom: 10px;">Delivery & Installation</h3>
        <p style="color: #555;">We ensure safe delivery and professional installation at your site for complete satisfaction.</p>
      </div>

      <!-- Step 6 -->
      <div class="step" style="flex: 1 1 30%; background: #fff; padding: 30px; border-radius: 12px; box-shadow: 0 8px 20px rgba(0,0,0,0.1); text-align: center;">
        <div class="step-number" style="font-size: 28px; font-weight: bold; color: #ff6600; margin-bottom: 15px;">06</div>
        <h3 style="font-size: 22px; color: #222; margin-bottom: 10px;">After-Sales Support</h3>
        <p style="color: #555;">Our support team provides reliable maintenance and guidance even after project completion.</p>
      </div>

    </div>
  </div>
</section>

        <!-- start about-section -->
       <section class="about-section">
    <div class="content">
        <div class="left-col">
            <div class="inner">
                <h3>Sheefa Fabrication Engineering Works – Quality Fabrication for Every Industry</h3>
                <p>Sheefa Fabrication Engineering Works specializes in delivering premium-quality metal fabrication, steel structures, and custom engineering solutions for industrial, commercial, and residential projects. With a commitment to precision, durability, and innovative design, we provide reliable fabrication services such as roofing structures, portable cabins, sheds, gates, railings, and customized steel work. Our focus on quality workmanship and on-time delivery makes us a trusted partner for clients seeking long-lasting and cost-effective engineering solutions.</p>
                
                <div class="social">
                    <span>Get Connected With Us:</span>
                    <ul>
                        <li><a href="#"><i class="fa-brands fa-facebook"></i></a></li>
                        <li><a href="#"><i class="fa-brands fa-twitter"></i></a></li>
                        <li><a href="#"><i class="fa-brands fa-instagram"></i></a></li>
                        <li><a href="#"><i class="fa-brands fa-linkedin"></i></a></li>
                    </ul>
                </div>
            </div>
        </div>

        <div class="right-col">
            <div class="video-holder">
               <!--  <a href="https://www.youtube.com/embed/7e90gBu4pas?autoplay=1" class="video-btn" data-type="iframe">
                    <i class="fa fa-play"></i> Play Video
                </a> -->
            </div>
        </div>
    </div> <!-- end content -->
</section>






        <!-- end about-section -->

<section class="sheefa-mv" aria-labelledby="sheefa-mv-title">
  <div class="container">
    <header class="mv-header">
      <div class="mv-sub">Our Commitment</div>
      <h2 id="sheefa-mv-title">Sheefa Fabrication Engineering Works Mission &amp; Vision</h2>
      <p class="lead">Delivering precision metal fabrication, robust roofing, and dependable engineering solutions with safety, quality and customer satisfaction at the core.</p>
    </header>

    <div class="mv-grid">
      <!-- Mission -->
      <article class="mv-card" aria-labelledby="mv-mission-title">
        <div class="mv-icon" aria-hidden="true">
          <!-- target icon (mission) -->
          <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
            <rect x="3" y="3" width="18" height="18" rx="3" stroke="#f36f21" stroke-width="1.6" fill="none"></rect>
            <path d="M8 12l2.2 2.4L16 8" stroke="#f36f21" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"></path>
          </svg>
        </div>

        <div class="mv-body">
          <h3 id="mv-mission-title">Our Mission</h3>
          <p>To provide high-quality, durable fabrication and roofing solutions using skilled craftsmanship, trusted materials, and safe practices — ensuring every project is delivered on time and to the customer’s exact requirements.</p>
        </div>
      </article>

      <!-- Vision -->
      <article class="mv-card" aria-labelledby="mv-vision-title">
        <div class="mv-icon" aria-hidden="true">
          <!-- upward arrow icon (vision) -->
          <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
            <rect x="3" y="3" width="18" height="18" rx="3" stroke="#0f2740" stroke-width="1.2" fill="none"></rect>
            <path d="M7 13l5-6 5 6" stroke="#0f2740" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"></path>
            <path d="M12 7v10" stroke="#0f2740" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"></path>
          </svg>
        </div>

        <div class="mv-body">
          <h3 id="mv-vision-title">Our Vision</h3>
          <p>To be a leading fabrication engineering partner recognized for innovation, reliability and excellence — expanding capabilities while maintaining the highest standards of safety and service.</p>
        </div>
      </article>
    </div>

    <div class="cta-row" role="group" aria-label="mission vision actions">
      <a class="btn-primary" href="#contact">Request a Quote</a>
      <a class="btn-outline" href="#about">Learn More</a>
    </div>
  </div>
</section>




<section class="why-choose">
    <div class="container">
        
        <div class="wc-header">
            <h2>Why Choose Us</h2>
            <p>Sheefa Fabrication Engineering Works delivers reliable, durable and high-quality fabrication solutions designed for long-term performance.</p>
        </div>

        <div class="wc-grid">

            <!-- Card 1 -->
            <div class="wc-card">
                <div class="wc-icon">
                    <i class="fa fa-check-circle"></i>
                </div>
                <h3>High-Quality Fabrication</h3>
                <p>We use premium-grade materials and skilled craftsmanship to ensure long-lasting, high-precision fabrication work.</p>
            </div>

            <!-- Card 2 -->
            <div class="wc-card">
                <div class="wc-icon">
                    <i class="fa fa-industry"></i>
                </div>
                <h3>Advanced Engineering</h3>
                <p>Our team follows modern fabrication techniques, machinery, and engineering standards for the best results.</p>
            </div>

            <!-- Card 3 -->
            <div class="wc-card">
                <div class="wc-icon">
                    <i class="fa fa-clock-o"></i>
                </div>
                <h3>On-Time Delivery</h3>
                <p>We plan, execute, and complete every fabrication project within the committed timeline without compromising quality.</p>
            </div>

            <!-- Card 4 -->
            <div class="wc-card">
                <div class="wc-icon">
                    <i class="fa fa-users"></i>
                </div>
                <h3>Trusted by Clients</h3>
                <p>Our dedication, transparency, and professional approach make us a preferred choice in the fabrication industry.</p>
            </div>

        </div>

    </div>
</section>

        <!-- start projects-section -->
        <section class="projects-section section-padding">
            <div class="container-fluid">
                <div class="row">
                    <div class="col col-lg-8 col-lg-offset-2 col-sm-10 col-sm-offset-1">
                        <div class="section-title">
                            <h2>Our Work With Us.</h2>
                            <p>Sheefa Fabrication Engineering Works</p>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col col-xs-12 sortable-gallery">
                        <div class="gallery-filters">
                            <ul>
                                <li><a data-filter="*" href="#" class="current">All</a></li>
                                <li><a data-filter=".construction" href="#">Fabrication Service</a></li>
                                <li><a data-filter=".plant" href="#">Prefabricated Structure</a></li>
                                <li><a data-filter=".mechanical" href="#">Roofing Sheet</a></li>
                                <li><a data-filter=".welding" href="#">Prefabricated Factory Shed</a></li>
                            </ul>
                        </div>

                        <div class="gallery-container">
                            <div class="box construction">
                            <img src="assets/images/product-jpeg-500x500.jpg" alt="">
                                <div class="details">
                                    <div class="info">
                                        <span class="cat">₹ 15 / sq ft</span>
                                        <h3><a href="#">Prefabricated Industrial Shed</a></h3>
                                    </div>
                                </div>
                            </div>
                            <div class="box construction plant">
                                <img src="assets/images/ui.jpg" alt>
                                <div class="details">
                                    <div class="info">
                                        <span class="cat">₹ 15 / sq ft</span>
                                        <h3><a href="#">Roofing Sheets Installation Services</a></h3>
                                    </div>
                                </div>
                            </div>
                            <div class="box plant construction">
                                <img src="assets/images/projects/1.jpg" alt>
                                <div class="details">
                                    <div class="info">
                                       <span class="cat">₹ 15 / sq ft</span>
                                        <h3><a href="#">Roofing Sheets Installation Services</a></h3>
                                    </div>
                                </div>
                            </div>
                            <div class="box construction mechanical">
                                <img src="assets/images/projects/2.jpg" alt>
                                <div class="details">
                                    <div class="info">
                                     <!--    <span class="cat">Melbourne, AU</span>
                                        <h3><a href="#">Mechanical Works</a></h3> -->
                                    </div>
                                </div>
                            </div>
                            <div class="box plant welding">
                                <img src="assets/images/projects/3.jpg" alt>
                                <div class="details">
                                    <div class="info">
                                     <!--    <span class="cat">Melbourne, AU</span>
                                        <h3><a href="#">Mechanical Works</a></h3> -->
                                    </div>
                                </div>
                            </div>
                            <div class="box mechanical">
                                <img src="assets/images/projects/4.jpg" alt>
                                <div class="details">
                                    <div class="info">
                                      <!--   <span class="cat">Melbourne, AU</span>
                                        <h3><a href="#">Mechanical Works</a></h3> -->
                                    </div>
                                </div>
                            </div>
                            <div class="box construction">
                                <img src="assets/images/projects/5.jpg" alt>
                                <div class="details">
                                    <div class="info">
                                      <!--   <span class="cat">Melbourne, AU</span>
                                        <h3><a href="#">Mechanical Works</a></h3> -->
                                    </div>
                                </div>
                            </div>
                            <div class="box plant welding">
                                <img src="assets/images/projects/7.jpg" alt>
                                <div class="details">
                                    <div class="info">
                                      <!--   <span class="cat">Melbourne, AU</span>
                                        <h3><a href="#">Mechanical Works</a></h3> -->
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- end projects-section -->


        <!-- start testimonials-section -->
       <section class="testimonials-section">
    <div class="container">
        <div class="row">
            <div class="col col-lg-3 col-md-4">
                <div class="section-title-s2">
                    <h2>Reviews of <br>Our Clients</h2>
                </div>
            </div>
            <div class="col col-lg-8 col-md-8">
                <p>Our clients trust Sheefa Fabrication Engineering Works for high-quality steel fabrication, durable structures, and timely project delivery. Here’s what they say about our workmanship, reliability, and professional service.</p>
            </div>
        </div>

        <div class="row">
            <div class="col col-lg-11 col-lg-offset-1">
                <div class="testimonials-grids testimonials-slider">

                    <!-- Testimonial 1 -->
                    <div class="grid">
                        <div class="img-holder">
                            <img src="assets/images/testimonials/img-1.jpg" alt>
                        </div>
                        <div class="details">
                            <h3>“Excellent Quality & Fast Delivery”</h3>
                            <span class="client-info">- Imran Shaikh, Project Manager</span>
                            <p>Sheefa Fabrication Engineering Works completed our industrial shed fabrication perfectly and ahead of schedule. The material quality, welding work, and finishing were outstanding. Highly reliable team and very professional service.</p>
                            <div class="rating">
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                            </div>
                        </div>
                    </div>

                    <!-- Testimonial 2 -->
                    <div class="grid">
                        <div class="img-holder">
                            <img src="assets/images/testimonials/img-1.jpg" alt>
                        </div>
                        <div class="details">
                            <h3>“Strong & Durable Fabrication Work”</h3>
                            <span class="client-info">- Ramesh Kumar, Factory Owner</span>
                            <p>The team delivered a perfect color roofing structure for our factory. The installation was smooth, and the final finish was highly durable. Sheefa Fabrication Engineering Works is our first choice for all steel fabrication projects.</p>
                            <div class="rating">
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                            </div>
                        </div>
                    </div>

                    <!-- Testimonial 3 (Optional Add) -->
                    <div class="grid">
                        <div class="img-holder">
                            <img src="assets/images/testimonials/img-1.jpg" alt>
                        </div>
                        <div class="details">
                            <h3>“Professional Team & Great Support”</h3>
                            <span class="client-info">- Neha Patil, Interior Contractor</span>
                            <p>From portable cabins to railing fabrication, their work is always precise and well-finished. The team listens carefully, gives expert suggestions, and delivers exactly what we need. Highly recommended.</p>
                            <div class="rating">
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>

    </div>
</section>

        <!-- end testimonials-section -->


        <!-- start partners -->
        <section class="partners-section" style="display: none ;">
            <h2 class="hidden">Partners</h2>
            <div class="container">
                <div class="row">
                    <div class="col col-xs-12">
                        <div class="partners-slider">
                            <div class="grid">
                                <img src="assets/images/partners/img-1.png" alt>
                            </div>
                            <div class="grid">
                                <img src="assets/images/partners/img-2.png" alt>
                            </div>
                            <div class="grid">
                                <img src="assets/images/partners/img-3.png" alt>
                            </div>
                            <div class="grid">
                                <img src="assets/images/partners/img-4.png" alt>
                            </div>
                            <div class="grid">
                                <img src="assets/images/partners/img-2.png" alt>
                            </div>
                        </div>
                    </div>
                </div> <!-- end row -->
            </div> <!-- end container -->
        </section>
        <!-- end partners -->


        <!-- start contact-section -->
        <section class="contact-section section-padding">
            <div class="container">
                <div class="col col-lg-10">
                    <div class="row">
                        <div class="col col-lg-4 col-md-4">
                            <div class="section-title-s3">
                                <h2>Request a Quote</h2>
                            </div>
                        </div>
                        <div class="col col-lg-7 col-md-8">
                            <div class="title-text">
                                <p>For all your fabrication needs, Sheefa Fabrication Engineering Works is here to assist you</p>
                            </div>
                        </div>
                    </div>

                    <div class="contact-form form">
                        <form method="post" id="contact-form" class="contact-validation-active">
                            <div>
                                <label for="name">Full Name</label>
                                <input type="text" id="name" name="name" class="form-control">
                            </div>
                            <div>
                                <label for="email">Email</label>
                                <input type="email" id="email" name="email" class="form-control">
                            </div>
                            <div>
                                <label for="phone">Phone Number</label>
                                <input type="text" id="phone" name="phone" class="form-control">
                            </div>
                            <div>
                                <label>Choose a Service</label>
                                <select name="select" class="form-control">
                                    <option selected disabled> Choose Service</option>
                                    <option value="Select One">Fabrication Service</option>
                                    <option value="Select Two">Prefabricated Structure</option>
                                    <option value="Select Three">Roofing Sheet</option>
                                </select>
                            </div>
                            <div class="submit-btn-wrap">
                                <input value="Submit" type="submit">
                                <div id="loader">
                                    <i class="fa fa-refresh fa-spin fa-3x fa-fw"></i>
                                </div>
                            </div>
                            <div class="error-handling-messages">
                                <div id="success">Thank you</div>
                                <div id="error"> Error occurred while sending email. Please try again later. </div>
                            </div>
                        </form>
                    </div>                     
                </div>
            </div> <!-- end container -->
            <div class="contact-man">
                <img src="assets/images/contact-man.png" alt>
            </div>
        </section>
        <!-- end contact-section -->

  <?php include('footer.php');?>

    </div>
    <!-- end of page-wrapper -->



    <!-- All JavaScript files
    ================================================== -->
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>

    <!-- Plugins for this template -->
    <script src="assets/js/jquery-plugin-collection.js"></script>

    <!-- Google map api -->
    <script src="https://maps.googleapis.com/maps/api/js?key"></script>

    <!-- Custom script for this template -->
    <script src="assets/js/script.js"></script>
</body>
</html>
