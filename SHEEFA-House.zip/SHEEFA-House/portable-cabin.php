<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Meta Tags -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="author" content="themexriver">

    <!-- Page Title -->
    <title> Portable Cabin </title>

    <!-- Icon fonts -->
    <link href="assets/css/font-awesome.min.css" rel="stylesheet">
 <link rel="icon" type="image/x-icon" href="assets/images/sheefa-120x120.jpg">
    <!-- Bootstrap core CSS -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/7.0.1/css/all.min.css" />
    <!-- Plugins for this template -->
    <link href="assets/css/animate.css" rel="stylesheet">
    <link href="assets/css/owl.carousel.css" rel="stylesheet">
    <link href="assets/css/owl.theme.css" rel="stylesheet">
    <link href="assets/css/slick.css" rel="stylesheet">
    <link href="assets/css/slick-theme.css" rel="stylesheet">
    <link href="assets/css/owl.transitions.css" rel="stylesheet">
    <link href="assets/css/jquery.fancybox.css" rel="stylesheet">
    <link href="assets/css/magnific-popup.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="assets/css/style.css" rel="stylesheet">

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body>

    <!-- start page-wrapper -->
    <div class="page-wrapper">

        <!-- start preloader -->
        <div class="preloader">
            <div class="preloader-inner">
                <img src="assets/images/preloader.gif" alt>
            </div>
        </div>
        <!-- end preloader -->
<?php include('header.php');?>

        <!-- start page-title -->
        <section class="page-title">
            <div class="container">
                <div class="row">
                    <div class="col col-xs-12">
                        <div class="title-breadcrumb">
                            <h2>Service</h2>
                            <ol class="breadcrumb">
                                <li><a href="index.php">Home</a></li>
                                <li><strong style="color: #ff5e14;">Portable Cabin</strong></li>
                            </ol>
                        </div>
                    </div>
                </div> <!-- end row -->
            </div> <!-- end container -->
        </section>        
        <!-- end page-title -->


        <!-- start service-singel-section -->
        <section class="service-singel-section section-padding">
            <div class="container">
                <div class="row">
                    <div class="col col-md-8 col-md-push-4">
                        <div class="service-single-content">
                            <div>
                                <!-- <img src="assets/images/hh.png"  class="img-fluid"> -->
                                <div class="slider">
<div class="slides" id="slides">
<div class="slide"><img src="assets/images/29.jpg" alt="slide 1" class="img-fluid"></div>
<div class="slide"><img src="assets/images/30.jpg" alt="slide 2"></div>
<div class="slide"><img src="assets/images/31.jpg" alt="slide 3"></div>
<div class="slide"><img src="assets/images/33.jpg" alt="slide 4"></div>
</div>


<button class="nav1 prev" onclick="prevSlide()">❮</button>
<button class="nav1 next" onclick="nextSlide()">❯</button>


<div class="dots" id="dots">
<span class="dot active" onclick="goToSlide(0)"></span>
<span class="dot" onclick="goToSlide(1)"></span>
<span class="dot" onclick="goToSlide(2)"></span>
<span class="dot" onclick="goToSlide(3)"></span>
<span class="dot" onclick="goToSlide(4)"></span>
<span class="dot" onclick="goToSlide(5)"></span>
<span class="dot" onclick="goToSlide(6)"></span>
</div>
</div>
                            </div>
                            <div class="title">
                                <h3><strong style="color: #ff5e14;">Portable Accommodation Cabin </strong>₹ 1,250/sq ft</h3>
                                <h6></h6>
                                <div class="download">
                                    <a href="assets/images/sheefa-fabrication-engineering-works.pdf"><i class="fa fa-file-word-o"></i> Download Brochure</a>
                                   
                                </div>
                            </div>


                            <div class="details">
                                <p>Our Accommodation Cabins provide a comfortable, practical, and cost-effective housing solution for remote sites, construction camps, disaster relief areas, and temporary living needs. Designed with durability and convenience in mind, these cabins feature insulated walls, ventilation, lighting, and essential electrical fittings to ensure a safe and pleasant living environment. Units can be customized with beds, storage, air conditioning, and attached bathrooms to suit various occupancy requirements. Built from high-quality materials, they are weather-resistant, easy to transport, and quick to install. Whether for short-term stays or extended use, our Accommodation Cabins deliver comfort, privacy, and functionality in any location......

</p>


<ul>
  <li><i class="fa fa-plus"></i> Custom steel fabrication & <strong style="color: #ff5e14;">portable cabin</strong> solutions for industrial and commercial needs</li>
  <li><i class="fa fa-plus"></i> Precision fabrication, modular cabin manufacturing & on-site installation works</li>
  <li><i class="fa fa-plus"></i> Durable portable cabins for site offices, security cabins, labour accommodation & storage use</li>
  <li><i class="fa fa-plus"></i> Reliable project execution using quality materials, insulated panels & skilled manpower</li>
</ul>

<p>
  <strong style="color: #ff5e14;">Sheefa Fabrication Engineering Works</strong> is a trusted name in fabrication and
  <strong style="color: #ff5e14;">portable cabin</strong> solutions, delivering durable, cost-effective, and time-efficient
  modular structures. We specialize in manufacturing and installing high-quality portable cabins for site offices,
  security cabins, labour accommodations, warehouses, commercial spaces, and industrial projects.
</p>

<h4>Why Choose Sheefa Fabrication Engineering Works</h4>

<p>
  With experienced technicians, modern fabrication machinery, and advanced modular construction techniques, we ensure
  strong structures, proper insulation, clean finishing, and long-lasting performance. From design and fabrication to
  complete <strong style="color: #ff5e14;">portable cabin</strong> installation, we manage every project with
  professionalism, safety compliance, and strict quality control—making us a reliable partner for portable cabin and
  modular building requirements.
</p>




                                <a href="contact.php" class="theme-btn-s2">Contact us</a>
                            </div>
                         
                        </div> <!-- end service content -->
                    </div> <!-- end col -->
                    
                    <div class="col col-md-4 col-md-pull-8">
                        <div class="service-single-sidebar">
                            <div class="services-link-widget widget">
                                <ul>
                                   <li><a href="fabrication-service.php">Fabrication Service</a></li>
                                    <li><a href="prefabricated-structure.php">Prefabricated Structure</a></li>
                                    <li><a href="<strong style="color: #ff5e14;">roofing sheet</strong></a></li>
                                    <li><a href="testimonials.html">Ventilation Fan</a></li>
                                    <li><a href="faq.html">Portable Cabin</a></li>
                                     <li><a href="faq.html">Prefabricated Factory Shed</a></li>
                                      <li><a href="faq.html">Industrial Shed Fabrication</a></li>
                                </ul>
                            </div>


                            <div class="download-brocher-widget widget">
                                <a href="assets/images/sheefa-fabrication-engineering-works.pdf"><i class="fa fa-file-pdf-o"></i> Download brochure</a>
                            </div>
                            <div class="widget contact-widget">
                                <h3>Contact us for help?</h3>
                                <p>Tell us what you need, and we'll help you get quotes</p>
                                <a href="tel:+91 8043842442"><i class="fa-solid fa-phone"></i>&nbsp;&nbsp;+91 8043842442</a>
                            </div>

                            <style>
                                @media (max-width: 767px) {
    .section-padding {
        padding: 1px 0 !important;
    }
}


.faq-section{
margin-bottom:40px;
}


.faq-header h2{
font-size:32px;
margin-bottom:10px;
color:#222;
}


.faq-header p{
color:#666;
font-size:16px;
}


.faq-item{
border:1px solid #e5e5e5;
border-radius:6px;
margin-bottom:15px;
overflow:hidden;
}


.faq-question{
background:#f9fafb;
padding:10px 20px;
font-size:14px;
font-weight:600;
cursor:pointer;
display:flex;
justify-content:space-between;
align-items:center;
}


.faq-question span{
font-size:22px;
transition:0.3s;
}


.faq-item.active .faq-question span{
transform:rotate(45deg);
}


.faq-answer{
max-height:0;
overflow:hidden;
transition:max-height 0.4s ease;
background:#fff;
}


.faq-answer p{
padding:15px 20px;
color:#555;
font-size:15px;
line-height:1.6;
}


/* Responsive */
@media(max-width:600px){
.faq-header h2{
font-size:24px;
}
}
                            </style>

<div class="table-wrap" style="margin-top: 1em;">
<table>
<tr>
<td>Length</td>
<td>40 Feet</td>
</tr>
<tr>
<td>Material</td>
<td>Mild Steel</td>
</tr>
<tr>

</table>
</div>
<section class="faq-section">
  <div class="faq-container">
    <div class="faq-header">
      <h2>Frequently Asked Questions</h2>
      <p>Sheefa Fabrication Engineering Works</p>
    </div>

    <div class="faq-item">
      <div class="faq-question">
        What services does Sheefa Fabrication Engineering Works provide? <span>+</span>
      </div>
      <div class="faq-answer">
        <p>We specialize in steel fabrication, prefabricated structures, industrial sheds, PEB buildings, roofing sheet installation, <strong style="color: #ff5e14;">portable cabins</strong>, warehouses, gates, grills, and custom engineering solutions.</p>
      </div>
    </div>

    <div class="faq-item">
      <div class="faq-question">
        Do you provide <strong style="color: #ff5e14;">portable cabin</strong> manufacturing and installation services? <span>+</span>
      </div>
      <div class="faq-answer">
        <p>Yes, we design, manufacture, and install high-quality <strong style="color: #ff5e14;">portable cabins</strong> for site offices, security cabins, labour accommodations, storage units, and commercial use.</p>
      </div>
    </div>

 

    <div class="faq-item">
      <div class="faq-question">
        Do you provide prefabricated structure and PEB shed solutions? <span>+</span>
      </div>
      <div class="faq-answer">
        <p>Yes, we design, fabricate, and install prefabricated structures and PEB sheds for industrial, commercial, and warehouse applications.</p>
      </div>
    </div>

    <div class="faq-item">
      <div class="faq-question">
        Do you provide custom fabrication and portable cabin solutions? <span>+</span>
      </div>
      <div class="faq-answer">
        <p>Yes, we offer fully customized fabrication and <strong style="color: #ff5e14;">portable cabin</strong> solutions based on client requirements, layout preferences, and site conditions.</p>
      </div>
    </div>

    <div class="faq-item">
      <div class="faq-question">
        Which materials do you use for fabrication, portable cabins, and roofing? <span>+</span>
      </div>
      <div class="faq-answer">
        <p>We use high-quality mild steel, galvanized steel, insulated sandwich panels, PEB components, color-coated roofing sheets, GI sheets, polycarbonate sheets, and other durable materials.</p>
      </div>
    </div>

    <div class="faq-item">
      <div class="faq-question">
        Do you provide installation services? <span>+</span>
      </div>
      <div class="faq-answer">
        <p>Yes, our skilled team handles complete fabrication, prefabrication, <strong style="color: #ff5e14;">portable cabin</strong> installation, roofing sheet installation, and on-site execution with strict safety and quality standards.</p>
      </div>
    </div>

    <div class="faq-item">
      <div class="faq-question">
        What locations do you serve? <span>+</span>
      </div>
      <div class="faq-answer">
        <p>We serve clients across India for fabrication, prefabricated structures, <strong style="color: #ff5e14;">portable cabin</strong>, and roofing sheet projects. Please contact us for location-specific availability.</p>
      </div>
    </div>

  </div>
</section>




                        </div>
                    </div>
                </div> <!-- end row -->
            </div> <!-- end container -->
        </section>
        <!-- end service-single-section -->      


        <!-- start news-letter-section -->
  
    </div>
    <!-- end of page-wrapper -->

<?php include('footer.php');?>

    <!-- All JavaScript files
    ================================================== -->
    <script src="assets/js/jquery.min.js"></script>
    <script>
        let currentIndex = 0;
const slides = document.getElementById('slides');
const dots = document.querySelectorAll('.dot');
const totalSlides = 4;


function updateSlider() {
slides.style.transform = `translateX(-${currentIndex * 100}%)`;
dots.forEach(dot => dot.classList.remove('active'));
dots[currentIndex].classList.add('active');
}


function nextSlide() {
currentIndex = (currentIndex + 1) % totalSlides;
updateSlider();
}


function prevSlide() {
currentIndex = (currentIndex - 1 + totalSlides) % totalSlides;
updateSlider();
}


function goToSlide(index) {
currentIndex = index;
updateSlider();
}


// Auto slide
setInterval(nextSlide, 4000);


const faqItems = document.querySelectorAll('.faq-item');


faqItems.forEach(item => {
const question = item.querySelector('.faq-question');
question.addEventListener('click', () => {
faqItems.forEach(i => {
if(i !== item){
i.classList.remove('active');
i.querySelector('.faq-answer').style.maxHeight = null;
}
});


item.classList.toggle('active');
const answer = item.querySelector('.faq-answer');


if(item.classList.contains('active')){
answer.style.maxHeight = answer.scrollHeight + 'px';
} else {
answer.style.maxHeight = null;
}
});
});
    </script>
    <script src="assets/js/bootstrap.min.js"></script>

    <!-- Plugins for this template -->
    <script src="assets/js/jquery-plugin-collection.js"></script>

    <!-- Custom script for this template -->
    <script src="assets/js/script.js"></script>
</body>
</html>
