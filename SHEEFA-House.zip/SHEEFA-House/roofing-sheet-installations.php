<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Meta Tags -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="author" content="themexriver">

    <!-- Page Title -->
    <title> Roofing Sheet Installations </title>

    <!-- Icon fonts -->
    <link href="assets/css/font-awesome.min.css" rel="stylesheet">
 <link rel="icon" type="image/x-icon" href="assets/images/sheefa-120x120.jpg">
    <!-- Bootstrap core CSS -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/7.0.1/css/all.min.css" />
    <!-- Plugins for this template -->
    <link href="assets/css/animate.css" rel="stylesheet">
    <link href="assets/css/owl.carousel.css" rel="stylesheet">
    <link href="assets/css/owl.theme.css" rel="stylesheet">
    <link href="assets/css/slick.css" rel="stylesheet">
    <link href="assets/css/slick-theme.css" rel="stylesheet">
    <link href="assets/css/owl.transitions.css" rel="stylesheet">
    <link href="assets/css/jquery.fancybox.css" rel="stylesheet">
    <link href="assets/css/magnific-popup.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="assets/css/style.css" rel="stylesheet">

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body>

    <!-- start page-wrapper -->
    <div class="page-wrapper">

        <!-- start preloader -->
        <div class="preloader">
            <div class="preloader-inner">
                <img src="assets/images/preloader.gif" alt>
            </div>
        </div>
        <!-- end preloader -->
<?php include('header.php');?>

        <!-- start page-title -->
        <section class="page-title">
            <div class="container">
                <div class="row">
                    <div class="col col-xs-12">
                        <div class="title-breadcrumb">
                            <h2>Service</h2>
                            <ol class="breadcrumb">
                                <li><a href="index.php">Home</a></li>
                                <li><strong style="color: #ff5e14;">Roofing Sheet Installations</strong></li>
                            </ol>
                        </div>
                    </div>
                </div> <!-- end row -->
            </div> <!-- end container -->
        </section>        
        <!-- end page-title -->


        <!-- start service-singel-section -->
        <section class="service-singel-section section-padding">
            <div class="container">
                <div class="row">
                    <div class="col col-md-8 col-md-push-4">
                        <div class="service-single-content">
                            <div>
                                <!-- <img src="assets/images/hh.png"  class="img-fluid"> -->
                                <div class="slider">
<div class="slides" id="slides">
<div class="slide"><img src="assets/images/24.jpg" alt="slide 1" class="img-fluid"></div>
<div class="slide"><img src="assets/images/25.jpg" alt="slide 2"></div>
<div class="slide"><img src="assets/images/26.jpg" alt="slide 3"></div>
<div class="slide"><img src="assets/images/27.jpg" alt="slide 4"></div>
<div class="slide"><img src="assets/images/23.jpg" alt="slide 5"></div>
<div class="slide"><img src="assets/images/industrial-shed-500x500.jpg" alt="slide 6"></div>
</div>


<button class="nav1 prev" onclick="prevSlide()">❮</button>
<button class="nav1 next" onclick="nextSlide()">❯</button>


<div class="dots" id="dots">
<span class="dot active" onclick="goToSlide(0)"></span>
<span class="dot" onclick="goToSlide(1)"></span>
<span class="dot" onclick="goToSlide(2)"></span>
<span class="dot" onclick="goToSlide(3)"></span>
<span class="dot" onclick="goToSlide(4)"></span>
<span class="dot" onclick="goToSlide(5)"></span>
<span class="dot" onclick="goToSlide(6)"></span>
</div>
</div>
                            </div>
                            <div class="title">
                                <h3><strong style="color: #ff5e14;">Roofing Sheet Installations</strong></h3>
                                <h6></h6>
                                <div class="download">
                                    <a href="assets/images/sheefa-fabrication-engineering-works.pdf"><i class="fa fa-file-word-o"></i> Download Brochure</a>
                                   
                                </div>
                            </div>


                            <div class="details">
                             <p>We are providers of <strong>Roofing Sheet Installations</strong>, located in Surat-Gujarat. We deliver high-quality roofing structures at affordable prices and offer services all over India. For business inquiries, please contact us.</p> <p>Roofing sheets play a crucial role in protecting buildings from weather, maintaining structural strength, and enhancing durability in industrial and commercial spaces. At Sheefa Fabrication Engineering Works, we provide professional roofing sheet installation services designed to offer long-lasting protection, superior finish, and a comfortable environment. Our roofing solutions are ideal for factories, warehouses, industrial sheds, workshops, and commercial buildings. Using advanced installation techniques and quality materials, we ensure reliable roofing, minimal maintenance, and long-term performance—making our roofing solutions a smart and cost-effective choice for modern industrial and commercial needs.</p> <ul> <li><i class="fa fa-plus"></i> Industrial and commercial roofing sheet installation for factories, warehouses, and buildings</li> <li><i class="fa fa-plus"></i> Precision installation of metal sheets, insulated panels, and roof coverings</li> <li><i class="fa fa-plus"></i> Durable protection against heat, rain, and environmental wear</li> <li><i class="fa fa-plus"></i> Reliable project execution using quality roofing materials, modern tools, and skilled manpower</li> </ul> <p> <strong style="color: #ff5e14;">Sheefa Fabrication Engineering Works</strong> is a trusted name in <strong style="color: #ff5e14;">roofing sheet installations</strong>, delivering durable, energy-efficient, and cost-effective roofing solutions. We specialize in industrial roofing sheets, commercial roofing systems, and customized roof installation services for factories, warehouses, industrial sheds, workshops, and commercial buildings. </p> <h4>Why Choose Sheefa Fabrication Engineering Works</h4> <p> With experienced technicians, modern installation tools, and quality materials, we ensure precise roofing installation, long-lasting performance, and complete protection from the elements. From site assessment to complete <strong style="color: #ff5e14;">roofing sheet installation</strong>, we handle every project with professionalism, safety compliance, and strict quality control—making us a reliable partner for all industrial and commercial roofing needs. </p>



                                <a href="contact.php" class="theme-btn-s2">Contact us</a>
                            </div>
                          
                        </div> <!-- end service content -->
                    </div> <!-- end col -->
                    
                    <div class="col col-md-4 col-md-pull-8">
                        <div class="service-single-sidebar">
                            <div class="services-link-widget widget">
                                <ul>
                                   <li><a href="fabrication-service.php">Fabrication Service</a></li>
                                    <li><a href="prefabricated-structure.php">Prefabricated Structure</a></li>
                                    <li><a href="roofing-sheet.php">Roofing Sheet</a></li>
                                    <li><a href="roofing-sheet-installations.php">Roofing Sheet Installations</a></li>
                                    <li><a href="portable-cabin.php">Portable Cabin</a></li>
                                     <li><a href="prefabricated-factory-shed.php">Prefabricated Factory Shed</a></li>
                                      <li><a href="faq.html">Industrial Shed Fabrication</a></li>
                                </ul>
                            </div>


                            <div class="download-brocher-widget widget">
                                <a href="assets/images/sheefa-fabrication-engineering-works.pdf"><i class="fa fa-file-pdf-o"></i> Download brochure</a>
                            </div>
                            <div class="widget contact-widget">
                                <h3>Contact us for help?</h3>
                                <p>Tell us what you need, and we'll help you get quotes</p>
                                <a href="tel:+91 8043842442"><i class="fa-solid fa-phone"></i>&nbsp;&nbsp;+91 8043842442</a>
                            </div>

                            <style>
                                @media (max-width: 767px) {
    .section-padding {
        padding: 1px 0 !important;
    }
}


.faq-section{
margin-bottom:40px;
}


.faq-header h2{
font-size:32px;
margin-bottom:10px;
color:#222;
}


.faq-header p{
color:#666;
font-size:16px;
}


.faq-item{
border:1px solid #e5e5e5;
border-radius:6px;
margin-bottom:15px;
overflow:hidden;
}


.faq-question{
background:#f9fafb;
padding:10px 20px;
font-size:14px;
font-weight:600;
cursor:pointer;
display:flex;
justify-content:space-between;
align-items:center;
}


.faq-question span{
font-size:22px;
transition:0.3s;
}


.faq-item.active .faq-question span{
transform:rotate(45deg);
}


.faq-answer{
max-height:0;
overflow:hidden;
transition:max-height 0.4s ease;
background:#fff;
}


.faq-answer p{
padding:15px 20px;
color:#555;
font-size:15px;
line-height:1.6;
}


/* Responsive */
@media(max-width:600px){
.faq-header h2{
font-size:24px;
}
}
                            </style>

<div class="table-wrap" style="margin-top: 1em;">
<table>
<tr>
<td>Material</td>
<td>Stainless Steel</td>
</tr>
<tr>
<td>Mounted</td>
<td>Top</td>
</tr>
<tr>
<td>Automation Grade</td>
<td>Automatic</td>
</tr>
<tr>
<td>Color</td>
<td>Steel Color</td>
</tr>
<tr>
<td>Country of Origin</td>
<td>Made in India</td>

</tr>
</table>
</div>

<!-- Roofing Sheet Installations FAQ Section -->
<section class="faq-section">
  <div class="faq-container">
    <div class="faq-header">
      <h2>Roofing Sheet Installations</h2>
      <p>Sheefa Fabrication Engineering Works</p>
    </div>

    <div class="faq-item">
      <div class="faq-question">
        What types of roofing sheets do you install? <span>+</span>
      </div>
      <div class="faq-answer">
        <p>We install a variety of roofing sheets, including color-coated sheets, GI sheets, polycarbonate sheets, and other high-quality metal roofing options suitable for industrial, commercial, and warehouse structures.</p>
      </div>
    </div>

    <div class="faq-item">
      <div class="faq-question">
        Do you provide installation services for industrial and commercial roofs? <span>+</span>
      </div>
      <div class="faq-answer">
        <p>Yes, our skilled team handles precise installation for industrial, commercial, and warehouse roofs, ensuring proper alignment, sealing, and structural durability.</p>
      </div>
    </div>

    <div class="faq-item">
      <div class="faq-question">
        Do you offer maintenance or repair services for roofing sheets? <span>+</span>
      </div>
      <div class="faq-answer">
        <p>Yes, we provide maintenance, repair, and replacement services to keep your roofing sheets in optimal condition, preventing leaks and extending roof lifespan.</p>
      </div>
    </div>

    <div class="faq-item">
      <div class="faq-question">
        How long does a typical roofing sheet installation take? <span>+</span>
      </div>
      <div class="faq-answer">
        <p>The installation time depends on the size and complexity of the project. Our team works efficiently while maintaining quality and safety standards to complete installations on schedule.</p>
      </div>
    </div>

    <div class="faq-item">
      <div class="faq-question">
        Which locations do you serve for roofing sheet installation? <span>+</span>
      </div>
      <div class="faq-answer">
        <p>We serve clients across India for roofing sheet installations. Contact us to discuss your specific location and project requirements.</p>
      </div>
    </div>
    
  </div>
</section>






                        </div>
                    </div>
                </div> <!-- end row -->
            </div> <!-- end container -->
        </section>
        <!-- end service-single-section -->      


        <!-- start news-letter-section -->
  
    </div>
    <!-- end of page-wrapper -->

<?php include('footer.php');?>

    <!-- All JavaScript files
    ================================================== -->
    <script src="assets/js/jquery.min.js"></script>
    <script>
        let currentIndex = 0;
const slides = document.getElementById('slides');
const dots = document.querySelectorAll('.dot');
const totalSlides = 4;


function updateSlider() {
slides.style.transform = `translateX(-${currentIndex * 100}%)`;
dots.forEach(dot => dot.classList.remove('active'));
dots[currentIndex].classList.add('active');
}


function nextSlide() {
currentIndex = (currentIndex + 1) % totalSlides;
updateSlider();
}


function prevSlide() {
currentIndex = (currentIndex - 1 + totalSlides) % totalSlides;
updateSlider();
}


function goToSlide(index) {
currentIndex = index;
updateSlider();
}


// Auto slide
setInterval(nextSlide, 4000);


const faqItems = document.querySelectorAll('.faq-item');


faqItems.forEach(item => {
const question = item.querySelector('.faq-question');
question.addEventListener('click', () => {
faqItems.forEach(i => {
if(i !== item){
i.classList.remove('active');
i.querySelector('.faq-answer').style.maxHeight = null;
}
});


item.classList.toggle('active');
const answer = item.querySelector('.faq-answer');


if(item.classList.contains('active')){
answer.style.maxHeight = answer.scrollHeight + 'px';
} else {
answer.style.maxHeight = null;
}
});
});
    </script>
    <script src="assets/js/bootstrap.min.js"></script>

    <!-- Plugins for this template -->
    <script src="assets/js/jquery-plugin-collection.js"></script>

    <!-- Custom script for this template -->
    <script src="assets/js/script.js"></script>
</body>
</html>
